# PIEBOT

Required libraries to run locally
1. [nltk](https://www.nltk.org/install.html)
2. [contractions](https://pypi.org/project/contractions/)
3. [spaCy and en_core_web_sm](https://spacy.io/usage)
4. [requests](https://pypi.org/project/requests/)
5. [pySwip](https://pypi.org/project/pyswip/0.2.2/)